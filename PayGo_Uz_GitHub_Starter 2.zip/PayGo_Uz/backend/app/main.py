from datetime import datetime, timezone
from typing import Literal

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

app = FastAPI(
    title="PayGo_Uz API",
    description="Демонстрационный API. Не обрабатывает реальные платежи.",
    version="0.1.0",
)

# For local demo only. Restrict origins before deployment.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://127.0.0.1:5500", "http://localhost:5500", "null"],
    allow_credentials=False,
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)

class DemoOrderRequest(BaseModel):
    amount: float = Field(gt=0, le=100_000_000)
    currency: Literal["UZS", "USDT"] = "UZS"
    method: Literal["payme", "uzcard", "humo", "crypto_demo"] = "payme"
    description: str = Field(default="Демо-платёж", max_length=120)

@app.get("/")
def root():
    return {
        "service": "PayGo_Uz API",
        "mode": "DEMO",
        "message": "Демонстрационный API. Реальные платежи не подключены.",
    }

@app.get("/api/dashboard")
def dashboard():
    return {
        "mode": "DEMO",
        "balance_usdt": 1.86,
        "frozen_usdt": 0.00,
        "active_orders": 0,
        "usdt_rub_demo_rate": 87.32,
        "updated_at": datetime.now(timezone.utc).isoformat(),
        "notice": "Все значения демонстрационные.",
    }

@app.get("/api/orders")
def orders():
    return {"mode": "DEMO", "orders": []}

@app.post("/api/demo-orders")
def create_demo_order(request: DemoOrderRequest):
    # Intentionally does not move money or claim that a payment succeeded.
    return {
        "mode": "DEMO",
        "order_id": "PG-DEMO-" + datetime.now(timezone.utc).strftime("%Y%m%d%H%M%S"),
        "status": "created_demo",
        "amount": request.amount,
        "currency": request.currency,
        "method": request.method,
        "description": request.description,
        "message": "Создана только тестовая заявка. Деньги не списаны и платёж не подтверждён.",
    }
